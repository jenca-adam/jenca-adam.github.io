#!/usr/bin/sh
pip install sip
pip install pyqt5;
python -m"fcad.qtapp.main"
